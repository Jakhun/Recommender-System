                 """ Demo —— 波士顿房价数据——四种梯度下降法对比结果 """
#1.导包
import tensorflow as tf
from tensorflow.keras import *
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

#2.数据集
from sklearn.datasets import load_boston
boston=load_boston()
X_train, X_test, Y_train, Y_test = train_test_split(boston.data, boston.target, random_state=123, test_size=0.3)

##标准化
mean = X_train.mean(axis=0)
X_train -= mean
std = X_train.std(axis=0)
X_train /= std
X_test -= mean
X_test /= std

#3.模型搭建——以RMSPROP梯度下降为对照基础
from tensorflow.keras import layers
def build_model():
    model = tf.keras.models.Sequential()
    model.add(layers.Dense(128, activation='relu', #128层
    input_shape=(X_train.shape[1],)))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dense(1))       #网络的最后一层只有一个单元，是一个线性层。这是预测单一连续值的回归的典型设置。
    model.compile(optimizer='rmsprop', loss='mse', metrics=['mae'])   #loss用mse 因为是连续值预测回归
    return model

#4.4折交叉验证，得分loss
k = 4
num_val_samples = len(X_train) // k
num_epochs = 100
all_scores = []

for i in range(k):
    print('processing fold #', i)
    val_data = X_train[i * num_val_samples: (i + 1) * num_val_samples]
    val_targets = Y_train[i * num_val_samples: (i + 1) * num_val_samples]
    
    partial_X_train = np.concatenate(
        [X_train[:i * num_val_samples],
        X_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    partial_Y_train = np.concatenate(
        [Y_train[:i * num_val_samples],
        Y_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    model = build_model()
    model.fit(partial_X_train, partial_Y_train,
    epochs=num_epochs, batch_size=1, verbose=0) #batch设置为1
    val_mse = model.evaluate(val_data, val_targets, verbose=0) #计算交叉验证的mse
    all_scores.append(val_mse)

#5.查看rmsprop法的MSE结果
s1 = np.mean(all_scores)

#6.对比1- Adam梯度下降
def build_model2():
    model = tf.keras.models.Sequential()
    model.add(layers.Dense(128, activation='relu',
    input_shape=(X_train.shape[1],)))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dense(1))      
    adam = optimizers.Adam(lr=0.001, beta_1=0.9, beta_2=0.99, epsilon=1e-08, decay=0.0)
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])   
    return model

k = 4
num_val_samples = len(X_train) // k
num_epochs = 100
all_scores2 = []

for i in range(k):
    print('processing fold #', i)
    val_data = X_train[i * num_val_samples: (i + 1) * num_val_samples]
    val_targets = Y_train[i * num_val_samples: (i + 1) * num_val_samples]
    
    partial_X_train = np.concatenate(
        [X_train[:i * num_val_samples],
        X_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    partial_Y_train = np.concatenate(
        [Y_train[:i * num_val_samples],
        Y_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    model = build_model2()
    model.fit(partial_X_train, partial_Y_train,
    epochs=num_epochs, batch_size=1, verbose=0)
    val_mse = model.evaluate(val_data, val_targets, verbose=0)
    all_scores2.append(val_mse)

s2 = np.mean(all_scores2)

#7.对比2- SGD梯度下降
def build_model3():
    model = tf.keras.models.Sequential()
    model.add(layers.Dense(128, activation='relu',
    input_shape=(X_train.shape[1],)))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dense(1))       
    sgd = optimizers.SGD(lr=0.001, decay=1e-6, nesterov=True) #设置一下学习率0.001，太大的话跑不出来
    model.compile(optimizer=sgd, loss='mse', metrics=['mae'])   
    return model

k = 4
num_val_samples = len(X_train) // k
num_epochs = 100
all_scores3 = []

for i in range(k):
    print('processing fold #', i)
    val_data = X_train[i * num_val_samples: (i + 1) * num_val_samples]
    val_targets = Y_train[i * num_val_samples: (i + 1) * num_val_samples]
    
    partial_X_train = np.concatenate(
        [X_train[:i * num_val_samples],
        X_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    partial_Y_train = np.concatenate(
        [Y_train[:i * num_val_samples],
        Y_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    model = build_model3()
    model.fit(partial_X_train, partial_Y_train,
    epochs=num_epochs, batch_size=1, verbose=0)
    val_mse = model.evaluate(val_data, val_targets, verbose=0)
    all_scores3.append(val_mse)

s3 = np.mean(all_scores3)

#7.对比3- adagra自动学习率调整梯度下降
def build_model3():
    model = tf.keras.models.Sequential()
    model.add(layers.Dense(128, activation='relu',
    input_shape=(X_train.shape[1],)))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dense(1))       
    model.compile(optimizer='adagrad', loss='mse', metrics=['mae'])  
    return model

k = 4
num_val_samples = len(X_train) // k
num_epochs = 100
all_scores4 = []

for i in range(k):
    print('processing fold #', i)
    val_data = X_train[i * num_val_samples: (i + 1) * num_val_samples]
    val_targets = Y_train[i * num_val_samples: (i + 1) * num_val_samples]
    
    partial_X_train = np.concatenate(
        [X_train[:i * num_val_samples],
        X_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    partial_Y_train = np.concatenate(
        [Y_train[:i * num_val_samples],
        Y_train[(i + 1) * num_val_samples:]],
        axis=0)
    
    model = build_model3()
    model.fit(partial_X_train, partial_Y_train,
    epochs=num_epochs, batch_size=1, verbose=0)
    val_mse = model.evaluate(val_data, val_targets, verbose=0)
    all_scores4.append(val_mse)

s4 = np.mean(all_scores4)

#6.打印结果
print("Rsmprop梯度下降的mse为:",s1) 
print("Adam梯度下降的mse为:",s2) 
print("SGD梯度下降的mse为:",s3)
print("adagrad梯度下降的mse为:",s4)